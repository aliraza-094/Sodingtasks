1. Download the project from github repository 
2. Extract the project(admin).
3. Place unzipped project(admin) in dashboard folder under the htdocs folder in XAMPP.
   Xampp->htdocs->dashboard
4. Find the Sql file TaskSql.sql in the project(admin) folder. Import this file in mysql database of XAMPP phpmyadmin.
5. Run the Project from this UrL:   http://localhost/dashboard/admin/index.php

