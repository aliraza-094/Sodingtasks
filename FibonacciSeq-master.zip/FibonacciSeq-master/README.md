# FibonacciSeq
 Download the Java project from the repository.  
unzip the project.  
Import the project in eclipse.  
Run the project to generate Fibonacci Seq upto 4 millions.  
